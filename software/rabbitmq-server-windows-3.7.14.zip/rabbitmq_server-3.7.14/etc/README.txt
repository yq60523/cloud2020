In this directory you can find an example configuration file for RabbitMQ.

Note that this directory is *not* where the real RabbitMQ
configuration lives. The default location for the real configuration
file is %APPDATA%\RabbitMQ\rabbitmq.config.

%APPDATA% usually expands to C:\Users\%USERNAME%\AppData\Roaming or similar.
